// Prevent double submit for forms with data-submit-once.
// Disable after the form data is built, otherwise the clicked button's name/value is lost.
document.addEventListener('submit', (event) => {
	const form = event.target
	if (!(form instanceof HTMLFormElement) || !form.hasAttribute('data-submit-once')) return
	setTimeout(() => {
		for (const button of form.querySelectorAll('button[type="submit"]')) button.disabled = true
	}, 0)
})
