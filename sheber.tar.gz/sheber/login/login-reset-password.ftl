<#import "template.ftl" as layout>
<#import "components.ftl" as ui>
<#assign usernameLabel = (!realm.loginWithEmailAllowed)?then(msg("username"),
    (!realm.registrationEmailAsUsername)?then(msg("usernameOrEmail"), msg("email")))>
<@layout.registrationLayout displayInfo=true displayMessage=!messagesPerField.existsError('username'); section>
    <#if section = "header">
        ${msg("emailForgotTitle")}
    <#elseif section = "form">
        <p class="sh-description">
            <#if realm.duplicateEmailsAllowed>${msg("emailInstructionUsername")}<#else>${msg("emailInstruction")}</#if>
        </p>
        <form id="kc-reset-password-form" class="sh-form" action="${url.loginAction}" method="post" data-submit-once>
            <@ui.field name="username" label=usernameLabel value=(auth.attemptedUsername!'') autocomplete="username"
                autofocus=true error=messagesPerField.get('username')/>
            <@ui.button label=msg("doSubmit")/>
        </form>
    <#elseif section = "info">
        <a class="sh-link" href="${url.loginUrl}">${msg("backToLogin")}</a>
    </#if>
</@layout.registrationLayout>
