<#import "template.ftl" as layout>
<#import "components.ftl" as ui>
<#import "user-profile-commons.ftl" as userProfileCommons>
<#import "register-commons.ftl" as registerCommons>
<@layout.registrationLayout displayMessage=messagesPerField.exists('global') displayRequiredFields=true displayInfo=true; section>
    <#if section = "header">
        <#if messageHeader??>${kcSanitize(msg("${messageHeader}"))?no_esc}<#else>${msg("registerTitle")}</#if>
    <#elseif section = "form">
        <form id="kc-register-form" class="sh-form" action="${url.registrationAction}" method="post" data-submit-once>
            <#-- Fields come from the realm User Profile -->
            <@userProfileCommons.userProfileFormFields; callback, attribute>
                <#if callback = "afterField">
                    <#if passwordRequired?? && (attribute.name == 'username' || (attribute.name == 'email' && realm.registrationEmailAsUsername))>
                        <@ui.field name="password" label=msg("password") type="password" autocomplete="new-password"
                            required=true error=messagesPerField.get('password')/>
                        <@ui.field name="password-confirm" label=msg("passwordConfirm") type="password" autocomplete="new-password"
                            required=true error=messagesPerField.get('password-confirm')/>
                    </#if>
                </#if>
            </@userProfileCommons.userProfileFormFields>

            <@registerCommons.termsAcceptance/>

            <#if recaptchaRequired?? && (recaptchaVisible!false)>
                <div class="sh-field">
                    <div class="g-recaptcha" data-size="compact" data-sitekey="${recaptchaSiteKey}" data-action="${recaptchaAction}"></div>
                </div>
            </#if>

            <@ui.button label=msg("doRegister")/>
        </form>
    <#elseif section = "info">
        ${msg("haveAccount")} <a class="sh-link" href="${url.loginUrl}">${msg("doLogIn")}</a>
    </#if>
</@layout.registrationLayout>
