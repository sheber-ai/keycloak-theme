<#import "template.ftl" as layout>
<#import "components.ftl" as ui>
<#import "password-commons.ftl" as passwordCommons>
<@layout.registrationLayout displayMessage=!messagesPerField.existsError('password', 'password-confirm'); section>
    <#if section = "header">
        ${msg("updatePasswordTitle")}
    <#elseif section = "form">
        <form id="kc-passwd-update-form" class="sh-form" action="${url.loginAction}" method="post" data-submit-once>
            <@ui.field name="password-new" label=msg("passwordNew") type="password" autocomplete="new-password"
                autofocus=true error=messagesPerField.get('password')/>
            <@ui.field name="password-confirm" label=msg("passwordConfirm") type="password" autocomplete="new-password"
                error=messagesPerField.get('password-confirm')/>

            <div class="sh-options">
                <@ui.checkbox name="logout-sessions" label=msg("logoutOtherSessions") checked=true/>
            </div>

            <#if isAppInitiatedAction??>
                <div class="sh-actions">
                    <@ui.button label=msg("doSubmit") name="login"/>
                    <@ui.button label=msg("doCancel") name="cancel-aia" value="true" variant="secondary"/>
                </div>
            <#else>
                <@ui.button label=msg("doSubmit") name="login"/>
            </#if>
        </form>
    </#if>
</@layout.registrationLayout>
