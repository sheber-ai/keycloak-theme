
<#macro field name label type="text" value="" autocomplete="off" autofocus=false required=false error="">
    <div class="sh-field">
        <label for="${name}" class="sh-label">${label}<#if required> <span class="required">*</span></#if></label>
        <#if type == "password">
            <div class="sh-input-group" dir="ltr">
                <input id="${name}" name="${name}" type="password" class="sh-input"
                       autocomplete="${autocomplete}"<#if autofocus> autofocus</#if>
                       <#if error?has_content>aria-invalid="true" aria-describedby="input-error-${name}"</#if>/>
                <button type="button" class="sh-password-toggle" aria-controls="${name}" aria-label="${msg('showPassword')}"
                        data-password-toggle
                        data-icon-show="${properties.kcFormPasswordVisibilityIconShow!}"
                        data-icon-hide="${properties.kcFormPasswordVisibilityIconHide!}"
                        data-label-show="${msg('showPassword')}" data-label-hide="${msg('hidePassword')}">
                    <i class="${properties.kcFormPasswordVisibilityIconShow!}" aria-hidden="true"></i>
                </button>
            </div>
        <#else>
            <input id="${name}" name="${name}" type="${type}" class="sh-input" value="${value}"
                   autocomplete="${autocomplete}"<#if autofocus> autofocus</#if> dir="ltr"
                   <#if error?has_content>aria-invalid="true" aria-describedby="input-error-${name}"</#if>/>
        </#if>
        <#if error?has_content>
            <span id="input-error-${name}" class="sh-field-error" aria-live="polite">${kcSanitize(error)?no_esc}</span>
        </#if>
    </div>
</#macro>

<#-- variant: primary | secondary -->
<#macro button label name="" value="" variant="primary" type="submit">
    <button type="${type}" class="sh-btn sh-btn--${variant} sh-btn--block"<#if name?has_content> name="${name}"</#if><#if value?has_content> value="${value}"</#if>>${label}</button>
</#macro>

<#macro checkbox name label checked=false value="on">
    <label class="sh-checkbox-label">
        <input type="checkbox" class="sh-checkbox" id="${name}" name="${name}" value="${value}"<#if checked> checked</#if>/>
        <span>${label}</span>
    </label>
</#macro>

<#-- Same emblem as frontend/src/shared/design/logo.tsx -->
<#macro logo>
    <span class="sh-logo">
        <svg class="sh-logo-mark" viewBox="0 0 32 32" aria-hidden="true">
            <rect width="32" height="32" rx="8" fill="var(--sh-primary)"/>
            <path d="M22 10H12.5a3 3 0 0 0 0 6h7a3 3 0 0 1 0 6H10" fill="none" stroke="var(--sh-primary-foreground)"
                  stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span class="sh-logo-text">Sheber</span>
    </span>
</#macro>
