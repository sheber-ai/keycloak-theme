<#import "template.ftl" as layout>
<#import "components.ftl" as ui>
<#import "passkeys.ftl" as passkeys>
<#assign credentialsError = messagesPerField.getFirstError('username', 'password')>
<#assign usernameLabel = (!realm.loginWithEmailAllowed)?then(msg("username"),
    (!realm.registrationEmailAsUsername)?then(msg("usernameOrEmail"), msg("email")))>
<@layout.registrationLayout displayMessage=!messagesPerField.existsError('username', 'password') displayInfo=realm.password && realm.registrationAllowed && !registrationDisabled??; section>
    <#if section = "header">
        ${msg("loginAccountTitle")}
    <#elseif section = "form">
        <#if realm.password>
            <form id="kc-form-login" class="sh-form" action="${url.loginAction}" method="post" data-submit-once>
                <#if !usernameHidden??>
                    <@ui.field name="username" label=usernameLabel value=(login.username!'')
                        autocomplete=(enableWebAuthnConditionalUI?has_content)?then('username webauthn', 'username')
                        autofocus=true/>
                </#if>
                <@ui.field name="password" label=msg("password") type="password" autocomplete="current-password"
                    autofocus=usernameHidden?? error=credentialsError/>

                <div class="sh-options">
                    <#if realm.rememberMe && !usernameHidden??>
                        <@ui.checkbox name="rememberMe" label=msg("rememberMe") checked=login.rememberMe??/>
                    </#if>
                    <#if realm.resetPasswordAllowed>
                        <a class="sh-link" href="${url.loginResetCredentialsUrl}">${msg("doForgotPassword")}</a>
                    </#if>
                </div>

                <input type="hidden" id="id-hidden-input" name="credentialId"<#if auth.selectedCredential?has_content> value="${auth.selectedCredential}"</#if>/>
                <@ui.button label=msg("doLogIn") name="login"/>
            </form>
        </#if>
        <@passkeys.conditionalUIData/>
    <#elseif section = "info">
        ${msg("noAccount")} <a class="sh-link" href="${url.registrationUrl}">${msg("doRegister")}</a>
    <#elseif section = "socialProviders">
        <#if realm.password && social?? && social.providers?has_content>
            <div class="sh-social">
                <p class="sh-divider"><span>${msg("identity-provider-login-label")}</span></p>
                <div class="sh-social-list">
                    <#list social.providers as p>
                        <a id="social-${p.alias}" class="sh-btn sh-btn--secondary sh-btn--block" href="${p.loginUrl}">${p.displayName!}</a>
                    </#list>
                </div>
            </div>
        </#if>
    </#if>
</@layout.registrationLayout>
