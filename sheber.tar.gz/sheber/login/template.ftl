<#-- Keep the macro signature compatible with base/login/template.ftl: base pages render through it. -->
<#import "components.ftl" as ui>
<#macro registrationLayout bodyClass="" displayInfo=false displayMessage=true displayRequiredFields=false>
<!DOCTYPE html>
<html lang="${lang}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title>${msg("pageTitle")}</title>
    <link rel="icon" type="image/svg+xml" href="${url.resourcesPath}/img/favicon.svg">
    <link rel="stylesheet" href="${url.resourcesPath}/css/sheber.css">
    <#if scripts??>
        <#list scripts as script>
            <script src="${script}" type="text/javascript"></script>
        </#list>
    </#if>
    <script type="importmap">
        { "imports": { "rfc4648": "${url.resourcesCommonPath}/vendor/rfc4648/rfc4648.js" } }
    </script>
    <#-- Continue the flow if the user logs in from another tab -->
    <script type="module">
        <#outputformat "JavaScript">
        import { startSessionPolling } from ${(url.resourcesPath + "/js/authChecker.js")?c};
        startSessionPolling(${url.ssoLoginInOtherTabsUrl?c});
        </#outputformat>
    </script>
    <#if authenticationSession??>
        <script type="module">
            <#outputformat "JavaScript">
            import { checkAuthSession } from ${(url.resourcesPath + "/js/authChecker.js")?c};
            checkAuthSession(${authenticationSession.authSessionIdHash?c});
            </#outputformat>
        </script>
    </#if>
</head>
<body class="sh-body ${bodyClass}" data-page-id="login-${pageId}">
<div class="sh-page">
    <aside class="sh-brand" aria-hidden="true">
        <@ui.logo/>
        <div class="sh-brand-content">
            <p class="sh-brand-title">${msg("brandTitle")}</p>
            <ol class="sh-brand-steps">
                <li>${msg("brandStepImport")}</li>
                <li>${msg("brandStepConstructor")}</li>
                <li>${msg("brandStepContractor")}</li>
            </ol>
        </div>
        <p class="sh-brand-footer">© Sheber</p>
    </aside>

    <main class="sh-main">
        <div class="sh-card">
            <div class="sh-card-top">
                <span class="sh-card-logo"><@ui.logo/></span>
                <#if realm.internationalizationEnabled && locale.supported?size gt 1>
                    <nav class="sh-locales" aria-label="${msg("languageSwitcher")}">
                        <#list locale.supported?sort_by("languageTag")?reverse as l>
                            <a class="sh-locale<#if l.languageTag == locale.currentLanguageTag> is-active</#if>"
                               href="${l.url}" hreflang="${l.languageTag}" title="${l.label}">
                                <#if l.languageTag == "ru">Рус<#elseif l.languageTag == "kk">Қаз<#elseif l.languageTag == "en">Eng<#else>${l.languageTag?upper_case}</#if>
                            </a>
                        </#list>
                    </nav>
                </#if>
            </div>

            <header class="sh-card-header">
                <h1 class="sh-title"><#nested "header"></h1>
                <#if auth?has_content && auth.showUsername() && !auth.showResetCredentials()>
                    <#nested "show-username">
                    <div class="sh-attempted-user">
                        <span id="kc-attempted-username">${auth.attemptedUsername}</span>
                        <a id="reset-login" href="${url.loginRestartFlowUrl}">${msg("restartLoginTooltip")}</a>
                    </div>
                </#if>
                <#if displayRequiredFields>
                    <p class="sh-hint"><span class="required">*</span> ${msg("requiredFields")}</p>
                </#if>
            </header>

            <#if displayMessage && message?has_content && (message.type != 'warning' || !isAppInitiatedAction??)>
                <div class="sh-alert sh-alert--${message.type}" role="alert">
                    ${kcSanitize(message.summary)?no_esc}
                </div>
            </#if>

            <#nested "form">

            <#if auth?has_content && auth.showTryAnotherWayLink()>
                <form id="kc-select-try-another-way-form" class="sh-secondary-action" action="${url.loginAction}" method="post">
                    <input type="hidden" name="tryAnotherWay" value="on"/>
                    <button type="submit" class="sh-link-button">${msg("doTryAnotherWay")}</button>
                </form>
            </#if>

            <#if switchOrganizationEnabled?? && switchOrganizationEnabled>
                <form id="kc-switch-organization-form" class="sh-secondary-action" action="${url.loginAction}" method="post">
                    <input type="hidden" name="switchOrganization" value="true"/>
                    <button type="submit" class="sh-link-button">${msg("doSwitchOrganization")}</button>
                </form>
            </#if>

            <#nested "socialProviders">

            <#if displayInfo>
                <div class="sh-info">
                    <#nested "info">
                </div>
            </#if>
        </div>
    </main>
</div>
<script src="${url.resourcesPath}/js/passwordVisibility.js" type="module"></script>
<script src="${url.resourcesPath}/js/sheber.js"></script>
</body>
</html>
</#macro>
